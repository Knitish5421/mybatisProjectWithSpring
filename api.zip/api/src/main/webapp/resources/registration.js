let data = {};

	function populate(s1, s2) {
		var s1 = document.getElementById(s1);
		var s2 = document.getElementById(s2);
		s2.innerHTML = "";

		if (s1.value == "bihar") {
			var optionArray = [ "|", "patna|Patna", "gaya|Gaya", ];
		} else if (s1.value == "jharkhand") {
			var optionArray = [ "|", "dhanbaad|Dhanbaad", "ranchi|Ranchi", ];
		} else if (s1.value == "karnataka") {
			var optionArray = [ "|", "bangalore|Bangalore", "mysore|Mysore", ];
		}

		for ( var option in optionArray) {
			var pair = optionArray[option].split("|");
			var newOPtion = document.createElement("option");
			newOPtion.value = pair[0];
			newOPtion.innerHTML = pair[1];
			s2.options.add(newOPtion);
		}
	}

	function validate() {
		myForm = document.myform;
		var fn = myForm.firstname.value;
		var fn1=  fn.charCodeAt(0);
		if (fn === '') {
			document.getElementById('firstname').innerHTML = "please enter the firstname ";
			myForm.firstname.focus;
			return false;
		} else if (fn1 >=0&&fn1<=64 ||fn1>=92&&fn1<=96 ) {
			document.getElementById('firstname').innerHTML = "please enter only string ";
			
			return false;
		}

		else {
			document.getElementById('firstname').innerHTML = "";
		}
		var ln = myForm.lastname.value;
		var ln1=  ln.charCodeAt(0);
		
		if (ln === '' || ln.length > 50) {
			document.getElementById('lastname').innerHTML = "please enter the lastname";
			myForm.lastname.focus;
			return false;
		} else if (ln1 >=0&&ln1<=64 ||ln1>=92&&ln1<=96 ) {
			document.getElementById('lastname').innerHTML = "please enter only string ";
			myForm.lastname.focus;
			return false;
		}
		 else {
			document.getElementById('lastname').innerHTML = "";
		}
		var gender = myForm.gender.value;
		if (gender === '') {
			document.getElementById('gender').innerHTML = "Please select gender";
			return false;
		} else {
			document.getElementById('gender').innerHTML = "";
		}
		var age = myForm.age.value;
		if (age=='') {
			alert(age);
			document.getElementById('age').innerHTML = "please enter the age";
			return false;
		}
		else if (isNaN(age) || age.length >= 3|| age=='') {
			document.getElementById('age').innerHTML = "Only Integer and 2 digits";
			return false;
		} else {
			document.getElementById('age').innerHTML = "";
		}
		var sal = myForm.salary.value;
		if (sal=='') {
			document.getElementById('salary').innerHTML = "please enter the salary";
		    return false;	
		}
		
		else if (isNaN(sal) || sal.length >= 6) {
			document.getElementById('salary').innerHTML = "Only Integer and 5 digits";
		    return false;	
		} else {
			document.getElementById('salary').innerHTML = "";
		}
		var deptId = myForm.deptId.value;
		if (deptId === '') {
			document.getElementById('dept').innerHTML = "Please select atleast one department";
		    return false;	
		} else {
			document.getElementById('dept').innerHTML = "";
		}
		var state = myForm.slct1.value
		if (state === '') {
			document.getElementById('state').innerHTML = "Please select atleast one state";
		    return false;	
		} else {
			document.getElementById('state').innerHTML = "";
		}
		var city = myForm.slct2.value;
		if (city === '') {
			document.getElementById('city').innerHTML = "Please select atleast one city";
		    return false;	
		} else {
			document.getElementById('city').innerHTML = ""
		}
		var java = document.getElementById("java").checked;
		var js = document.getElementById("js").checked;
		var j2ee = document.getElementById("j2ee").checked;
		if (!java && !js && !j2ee) {
			document.getElementById('skill').innerHTML = "Please select atleast one skill";
		    return false;	
		} else {
			document.getElementById('skill').innerHTML = "";
		}
	}

	function clearForm() {
		var frm_elements = document.getElementById('myForm');
		for (i = 0; i < frm_elements.length; i++) {
			field_type = frm_elements[i].type.toLowerCase();
			<!--
			console.log(field_type);
			-->
			switch (field_type) {
			case "text":
				frm_elements[i].value = "";
				break;
			case "password":
			case "textarea":
			case "number":
				frm_elements[i].value = "";
				break;
			case "hidden":
				frm_elements[i].value = "";
				break;
			case "radio":
			case "checkbox":
				if (frm_elements[i].checked) {
					frm_elements[i].checked = false;
				}
				break;
			case "select-one":
			case "select-multi":
				frm_elements[i].selectedIndex = -1;
				break;
			default:
				break;
			}
		}
	}