package com.prohance.mapper.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.prohance.confi.MyBatisUtil;
import com.prohance.controller.Department;
import com.prohance.controller.SunBurst;
import com.prohance.model.Employee;
@Service
public class EmployeeMapper {
	
	
	public List<Employee> getAllEmployees() {
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		List<Employee> list = session.selectList("EmployeeMapper.getAllEmployees");
		session.commit();
		session.close();
	    return list; 
	}
	
	public void deletById(Long id) {
		SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
		session.delete("EmployeeMapper.deleteById", id);
		session.commit();
		session.close();
	}
	
public Employee getDataById(Long id) {
	SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
	Employee employee = session.selectOne("EmployeeMapper.getById",id );
	session.commit();
	session.close();
	return employee;
	
}
	
public void updateById(Employee employee)
{
	SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
	session.update("EmployeeMapper.update",employee );
	session.commit();
	session.close();
	
}

public void insertEmployee(Employee employee)
{
SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
session.insert("EmployeeMapper.insert",employee );
session.commit();
session.close();

}

public List<Employee> findCityCount()
{
	
	SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
	List<Employee> city = session.selectList("EmployeeMapper.cityByEmployee");
	session.commit();
	session.close();
	return city;	
}

public List<Employee> findStateCount()
{
	SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
	List<Employee> state = session.selectList("EmployeeMapper.stateByEmployee");
	session.commit();
	session.close();
	return state;
}



public List<Employee> finddept()
{
	SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
	List<Employee> department = session.selectList("EmployeeMapper.deptByEmployee");
	session.commit();
	session.close();
	return department;	
}

public Employee getRow(Long id) {
	SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
	Employee employee = session.selectOne("EmployeeMapper.singleRow",id );
	session.commit();
	session.close();
	return employee;
	
}
/*
public Employee CityDataAnalaysis(String city) {
	SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
	Employee employee = session.selectOne("EmployeeMapper.cityByData",city );
	session.commit();
	session.close();
	return employee;
	
}
*/

public List<Employee> CityDataAnalaysis(@Param("city")String city) {
	Employee emp=new Employee();
	System.out.println(city);
	if(city!=null)
	{
		emp.setCity(city);	
	}
	
	SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
	List<Employee> lists = session.selectList("EmployeeMapper.cityByData",emp);
	session.commit();
	session.close();
    return lists; 
}

public List<Employee> deptDataAnalaysis(@Param("deptName")String deptName) {
	Employee emp=new Employee();
	System.out.println(deptName);
	if(deptName!=null)
	{
		emp.setDeptName(deptName);
	}
	
	SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
	List<Employee> lists = session.selectList("EmployeeMapper.Data",emp);
	session.commit();
	session.close();
    return lists; 
}
public List<SunBurst> getSunBurst() {
	SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
	List<SunBurst> sunBurstList = session.selectList("EmployeeMapper.Data1");
	session.commit();
	session.close();
    return sunBurstList; 
}


public List<Department> getAllDept()
{
	SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
	List<Department> allDept = session.selectList("EmployeeMapper.allDept");
	session.commit();
	session.close();
	return allDept;
}







	
	

}
