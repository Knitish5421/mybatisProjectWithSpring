package com.prohance.controller;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;

import com.prohance.confi.MyBatisUtil;
@Controller
public class LogOutController {
	@RequestMapping("/Prohance/logout")
	public RedirectView logOut()
	{
		
		RedirectView redirectView = new RedirectView();
	
		redirectView.setContextRelative(true);
		redirectView.setUrl("/Prohance");
		return redirectView;
	}
	

}
