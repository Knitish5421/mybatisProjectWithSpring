package com.prohance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.prohance.mapper.dao.EmployeeMapper;
import com.prohance.model.Employee;

@Controller
public class DashBoardController {
	
	@Autowired
	EmployeeMapper employeeMapper;
	
	
	@RequestMapping("/getHighChartDetailsDepartMentWise")
	public String getDepartmentWiseDetails(ModelMap modelMap) {
		List<Employee> city = employeeMapper.findCityCount();
		List<Employee> state= employeeMapper.findStateCount();
		List<Employee> department= employeeMapper.finddept();
	    modelMap.addAttribute("department", department);
		modelMap.addAttribute("city", city);
		modelMap.addAttribute("state", state);
		return "employeeDashBoard";
	}	
	

	

	@RequestMapping("/getHighChart")
	public String getDepartmentWiseDetail(ModelMap modelMap) {
		List<Employee> city = employeeMapper.findCityCount();
		List<Employee> state= employeeMapper.findStateCount();
		List<Employee> department= employeeMapper.finddept();
	    modelMap.addAttribute("department", department);
		modelMap.addAttribute("city", city);
		modelMap.addAttribute("state", state);
		return "Test";
	}	
	
	
	
}
