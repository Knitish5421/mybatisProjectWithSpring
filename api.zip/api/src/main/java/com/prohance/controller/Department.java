package com.prohance.controller;

import java.util.ArrayList;

public class Department {

	//public ArrayList<State> listofstate;


	/*public ArrayList<State> getListofstate() {
		return listofstate;
	}

	public void setListofstate(ArrayList<State> listofstate) {
		this.listofstate = listofstate;
	}*/
	//private int deptId;
	private String deptName;
	private State state;

	/*public int getDeptId() {
		return deptId;
	}

	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}*/

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}
}
