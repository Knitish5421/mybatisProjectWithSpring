package com.prohance.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.view.RedirectView;

import com.prohance.mapper.dao.EmployeeMapper;
import com.prohance.model.Employee;
import com.prohance.service.Service;

@Controller
public class ViewController {
	
	@Autowired
	EmployeeMapper employeeMapper;
	
	@RequestMapping("/employeeDetails")
	public String getAllEmployee(@RequestParam( required = false, value="page") Integer page, @RequestParam( required = false, value="msg") String msg,
			@RequestParam( required = false, value="city") String city, ModelMap modelMap) {
		if (page == null) page = 1;
		Integer a=(page * 5) - 5;
		Integer b=a+5;
		java.util.List<Employee> employeeList=null;
		//System.out.println(city);
	
		/*
		if(city!=null)
		{
			employeeList=employeeMapper.CityDataAnalaysis(city);
		}
		else
		{
			employeeList= employeeMapper.getAllEmployees();
		}
		*/
		
		//employeeList= employeeMapper.getAllEmployees();
		employeeList=employeeMapper.CityDataAnalaysis(city);
		
		
		Integer size = employeeList.size();
		if (b > size) b = size;
		employeeList = employeeList.subList(a,b);
		modelMap.addAttribute("size", size);
		//System.out.println(size);
		if (msg != null) modelMap.addAttribute("updateMessage", msg);
		modelMap.addAttribute("empDetails", employeeList);
		
		return "employeeView";
	}
	/*
	@RequestMapping("/employeeDetails1")
	public String getAllEmployee1(@RequestParam( required = false, value="page") Integer page, @RequestParam( required = false, value="msg") String msg, @RequestParam( required = false, value="city") String city, ModelMap modelMap) {
		if (page == null) page = 1;
		Integer a=(page * 5) - 5;
		Integer b=a+5;
		java.util.List<Employee> employeeList=null;
		System.out.println(city);
		String deptName=null;
		
		employeeList=employeeMapper.CityDataAnalaysis(city,deptName);
		
		
		Integer size = employeeList.size();
		if (b > size) b = size;
		employeeList = employeeList.subList(a,b);
		modelMap.addAttribute("size", size);
		//System.out.println(size);
		if (msg != null) modelMap.addAttribute("updateMessage", msg);
		modelMap.addAttribute("empDetails", employeeList);
		
		return "employeeView";
	}
	
	*/
	@RequestMapping("/employeeDetails2")
	public String getAllEmployee2(@RequestParam( required = false, value="page") Integer page, @RequestParam( required = false, value="msg") String msg, @RequestParam( required = false, value="deptName") String deptName, ModelMap modelMap) {
		if (page == null) page = 1;
		Integer a=(page * 5) - 5;
		Integer b=a+5;
		java.util.List<Employee> employeeList=null;
		//System.out.println(deptName);
		
		employeeList=employeeMapper.deptDataAnalaysis(deptName);
		
		
		Integer size = employeeList.size();
		if (b > size) b = size;
		employeeList = employeeList.subList(a,b);
		modelMap.addAttribute("size", size);
		//System.out.println(size);
		if (msg != null) modelMap.addAttribute("updateMessage", msg);
		modelMap.addAttribute("empDetails", employeeList);
		
		return "employeeView";
	}
	
	
	
	
	
	
	    @RequestMapping(value = "/login", method = RequestMethod.GET)
		public void redirectToTwitter(HttpServletResponse httpServletResponse) throws IOException {
		    httpServletResponse.sendRedirect("index");
		}
	    
	    
	    @RequestMapping("/register")
		public String registerEmployee(ModelMap modelMap) {
			modelMap.addAttribute("action", "registerEmployee");
			return "employeeForm";
		}
	    
	  
	    @RequestMapping(value = "/registerEmployee")
		public RedirectView employeeRegister(@ModelAttribute("empDetails") Employee empDetails, ModelMap modelMap) {
	    	employeeMapper.insertEmployee(empDetails);	
			RedirectView redirectView = new RedirectView();
			redirectView.setContextRelative(true);
			redirectView.setUrl("/employeeDetails?msg=Data successfully register for  "+empDetails.getFirstname()+" "+empDetails.getLastname());
			return redirectView;
		}
	    
	    
	    @RequestMapping("/deleteEmployee")
		public RedirectView deleteEmployee(@RequestParam("id")  Long id, ModelMap modelmap) {
	    	Employee employee = employeeMapper.getDataById(id);
	    	employeeMapper.deletById(id);			
			RedirectView redirectView = new RedirectView();
			redirectView.setContextRelative(true);
			redirectView.setUrl("/employeeDetails?msg=Data successfully deleted for "+employee.getFirstname()+" "+employee.getLastname());
			return redirectView;
		}
	    
	    
	    @RequestMapping("/showEmployeeModify")
		public String showUpdate(@RequestParam("id") Long id,ModelMap modelmap) {
	    	Employee details = employeeMapper.getDataById(id);;
			modelmap.addAttribute("empDetails", details);
			modelmap.addAttribute("value", details);
			modelmap.addAttribute("action", "modifyEmployee");
			return "employeeForm";
		}
	    
	    @RequestMapping("/modifyEmployee")
		public RedirectView modifyEmployee(@ModelAttribute("empDetails") Employee empDetails, ModelMap modelMap) {
	    	employeeMapper.updateById(empDetails);;
			RedirectView redirectView = new RedirectView();
			redirectView.setContextRelative(true);
			redirectView.setUrl("/employeeDetails?msg=Data successfully modify for employee "+empDetails.getFirstname()+" "+empDetails.getLastname());
			return redirectView;
		}
	    
	    //dailog box
	    @RequestMapping("/showEmployeeRow")
		public RedirectView showRow(@RequestParam("id") Long id,ModelMap modelmap) {
	    	Employee details = employeeMapper.getRow(id);
			modelmap.addAttribute("singleRow", details);
			RedirectView redirectView = new RedirectView();
			redirectView.setContextRelative(true);
			return redirectView;
		}
	    
}

 
