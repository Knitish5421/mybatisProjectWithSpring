package com.prohance.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.prohance.mapper.dao.EmployeeMapper;
import com.prohance.model.Employee;



@Controller
public class SunburstController {
	
	@Autowired
	EmployeeMapper  employeeMapper ;
	
	List<Employee>list;
	
	Parent parent;
	
	ObjectMapper mapper=new ObjectMapper();
	
	  @RequestMapping("/sunburst1")
	  public String sunburst(ModelMap modelMap) {
		  sunburstView();
		  try
			{
				String jsondata = mapper.writeValueAsString(parent);
				String jsonObject = jsondata.replace("listofdepartment", "children").replace("listofstate", "childrens").replace("listofcity", "children");
				jsonObject = jsonObject.replace("childrens", "children");
				System.out.println(jsonObject);
				modelMap.addAttribute("jsonObject", jsonObject);
			}
			catch (JsonProcessingException e)
			{
				e.printStackTrace();
			}
		  return "sunburst";
		}
	  
	  
	  private void sunburstView()
		{
			list = employeeMapper.getAllEmployees();
			Map<String, Integer> dept = new HashMap<String, Integer>();
			int oldval;
			int newval;
			for (Employee emp : list)
			{
				if (dept.containsKey(emp.getDeptName()))
				{
					oldval = dept.get(emp.getDeptName());
					newval = oldval + 1;
					dept.put(emp.getDeptName(), newval);
				}
				else
				{
					dept.put(emp.getDeptName(), 1);
				}
			}
			Set<Entry<String, Integer>> hmap = dept.entrySet();
			ArrayList<String> deptName = new ArrayList<String>();
			ArrayList<Integer> deptCount = new ArrayList<Integer>();

			for (Entry<String, Integer> map : hmap)
			{
				deptName.add(map.getKey());
				deptCount.add(map.getValue());
			}

			getstatelist(deptName, deptCount);

		}


		private void getstatelist(ArrayList<String> deptName, ArrayList<Integer> deptCount)
	{
		

		Map<String, Integer> stateMap;
		int oldVal;
		int newVal;
		Set<Map.Entry<String, Integer>> hmap;
		ArrayList<String> stateName = new ArrayList<String>();
		ArrayList<Integer> stateCount = new ArrayList<Integer>();
		for (String department : deptName)
		{
			stateMap = new HashMap<String, Integer>();
			for (Employee emp : list)
			{
				if (emp.getDeptName().equals(department))
				{
					if (stateMap.containsKey(emp.getState() + emp.getDeptName()))
					{
						oldVal = stateMap.get(emp.getState() + emp.getDeptName());
						newVal = oldVal + 1;
						stateMap.put(emp.getState() + emp.getDeptName(), newVal);
					}
					else
					{
						stateMap.put(emp.getState()+ emp.getDeptName(), 1);
					}
				}
			}
			hmap = stateMap.entrySet();
			for (Map.Entry<String, Integer> data : hmap)
			{
				stateName.add(data.getKey());
				stateCount.add(data.getValue());
			}
		}
		cityCount(deptName, deptCount, stateName, stateCount);
	}


		
		private void cityCount(ArrayList<String> deptName, ArrayList<Integer> deptCount, ArrayList<String> stateName, ArrayList<Integer> stateCount)
		{

			Map<String, Integer> dmap = null;
			int oldVal;
			int newVal;
			Set<Map.Entry<String, Integer>> hmap;
			ArrayList<String> cityName = new ArrayList<String>();
			ArrayList<Integer> cityCount = new ArrayList<Integer>();
			for (String state : stateName)
			{
				dmap = new HashMap<String, Integer>();
				for (Employee emp : list)
				{
					if (state.contains(emp.getState()))
					{
						if (dmap.containsKey(emp.getCity() + emp.getState() + emp.getDeptName()))
						{
							oldVal = dmap.get(emp.getCity() + emp.getState() + emp.getDeptName());
							newVal = oldVal + 1;
							dmap.put(emp.getCity() + emp.getState() + emp.getDeptName(), newVal);
						}
						else
						{
							dmap.put(emp.getCity() + emp.getState() + emp.getDeptName(), 1);
						}
					}
				}
				hmap = dmap.entrySet();
				for (Map.Entry<String, Integer> data : hmap)
				{
					cityName.add(data.getKey());
					cityCount.add(data.getValue());
				}

			}
			createJson(deptName, deptCount, stateName, stateCount, cityName, cityCount);
		}


		
		private void createJson(ArrayList<String> deptName, ArrayList<Integer> deptCount, ArrayList<String> stateName,
				ArrayList<Integer> stateCount, ArrayList<String> cityName, ArrayList<Integer> cityCount) {
		
			parent = new Parent();
			parent.setName("Department");
		
			Department dpmt=new Department();
			ArrayList<Department> departmentlist=new ArrayList<Department>();
			State st;
			ArrayList<State> statelist;
			City ct;
			ArrayList<City> citylist;
			int stateIndex = 0;
			int cityIndex = 0;
			String department = "";
			String state = "";
			String city = "";
			
			for (int i = 0; i < deptName.size(); i++)
			{
				st = new State();
				department = deptName.get(i) + "," + deptCount.get(i);
				dpmt.setDeptName(department);
			
		
				statelist = new ArrayList<State>();
				while (stateIndex < stateCount.size() && stateName.get(stateIndex).contains(deptName.get(i)))
				{
					st = new State();
					state = stateName.get(stateIndex).replace(deptName.get(i), "") + "," + stateCount.get(stateIndex++);
					st.setState(state);
					citylist = new ArrayList<City>();
					
					while (cityIndex < cityCount.size() && cityName.get(cityIndex).contains(stateName.get(stateIndex - 1)))
					{
						ct = new City();
						city = cityName.get(cityIndex).replace(stateName.get(stateIndex - 1), "") + "," + cityCount.get(cityIndex);
						ct.setCity(city);
						ct.setSize(cityCount.get(cityIndex++));
						citylist.add(ct);
					}
					st.setListofcity(citylist);
					statelist.add(st);
				}
				//dpmt.setListofstate(statelist);
				departmentlist.add(dpmt);
			}
			parent.setListofdepartment(departmentlist);;
		}	  	
}
