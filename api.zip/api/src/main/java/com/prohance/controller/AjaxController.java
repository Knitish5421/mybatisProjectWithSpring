package com.prohance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.prohance.mapper.dao.EmployeeMapper;
import com.prohance.model.Employee;

@RestController
public class AjaxController {
	@Autowired
	EmployeeMapper employeeMapper;
	
	@RequestMapping(value="/getDepartMentWiseDetailsForEmployee", method =RequestMethod.GET)
	@ResponseBody
	public List<Employee> getDepartMentWiseDetailsForEmployee()
	{
		List<Employee> department= employeeMapper.finddept();
		return department;	
	}
	
	
	@RequestMapping(value="/getEmployeeBasedOnCity", method =RequestMethod.GET)
	@ResponseBody
	public List<Employee> getEmployeeBasedOnCity()
	{
		List<Employee> city = employeeMapper.findCityCount();
		return city;	
	}
	
	@RequestMapping(value="/getEmployeeBasedOnState", method =RequestMethod.GET)
	@ResponseBody
	public List<Employee> getEmployeeBasedOnState()
	{
		List<Employee> state= employeeMapper.findStateCount();
		return state;

	}
	
	@RequestMapping(value="/getEmployeeRow", method =RequestMethod.GET)
	@ResponseBody
	public Employee getEmployeeRow(Long id)
	{
		Employee row= employeeMapper.getRow(id);
		return row;

	}
	

}
