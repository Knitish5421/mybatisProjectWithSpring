package com.prohance.controller;

import java.util.ArrayList;

public class State {

	public String state;
	public ArrayList<City> listofcity;

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public ArrayList<City> getListofcity() {
		return listofcity;
	}

	public void setListofcity(ArrayList<City> listofcity) {
		this.listofcity = listofcity;
	}
	
	
	
	
	

	private String stateName;
	private City city;

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public City getCity() {
		return city;
	}

	public void setCity(City city) {
		this.city = city;
	}

}
