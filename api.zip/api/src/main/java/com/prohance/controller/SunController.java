package com.prohance.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.prohance.mapper.dao.EmployeeMapper;
import com.prohance.model.Employee;

@Controller
public class SunController {

	@Autowired
	EmployeeMapper employeeMapper;

	ObjectMapper mapper = new ObjectMapper();
	
	@RequestMapping("/sunburst")
	public String sunburst(ModelMap modelMap, HttpServletRequest req, HttpServletResponse res) {
		List<SunBurst> sunBurstList = new ArrayList<SunBurst>();
		sunBurstList = getSunBurst();
		
		
		
		JSONObject sunBurstObj = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		JSONArray jsonArray1=new JSONArray(sunBurstList);
		
		System.out.println(jsonArray1);
		Iterator<SunBurst> itr = sunBurstList.iterator();
		int size = 40;
		while (itr.hasNext()) {
			SunBurst sunBurst = itr.next();
			if (sunBurst!=null) {
				sunBurstObj.put("deptName", sunBurst.getDeptName());
				sunBurstObj.put("state", sunBurst.getState());
				sunBurstObj.put("city", sunBurst.getCity());
				sunBurstObj.put("size", size);
				jsonArray.put(sunBurstObj);
			}

		}
		System.out.println(jsonArray);
		HttpSession session = req.getSession();
		res.setContentType("application/json");
		modelMap.addAttribute("JSON", jsonArray.toString());
		return "sunburst";
	}

	private List<SunBurst> getSunBurst() {
		List<SunBurst> sunBurstList = employeeMapper.getSunBurst();
		return sunBurstList;
	}
}
