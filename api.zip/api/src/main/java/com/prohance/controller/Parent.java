package com.prohance.controller;

import java.util.ArrayList;


public class Parent  {
	public String name;

	private ArrayList<Department>listofdepartment;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<Department> getListofdepartment() {
		return listofdepartment;
	}

	public void setListofdepartment(ArrayList<Department> listofdepartment) {
		this.listofdepartment = listofdepartment;
	}
	


}
