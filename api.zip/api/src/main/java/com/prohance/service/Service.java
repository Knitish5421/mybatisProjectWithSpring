package com.prohance.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.prohance.confi.MyBatisUtil;
import com.prohance.mapper.dao.EmployeeMapper;
import com.prohance.model.Employee;


public class Service  {
	public List<Employee> getAllEmployees() {
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		List<Employee> list = session.selectList("Employee.getAllEmployees");
		session.commit();
		session.close();
		  return list; 
	}

}
